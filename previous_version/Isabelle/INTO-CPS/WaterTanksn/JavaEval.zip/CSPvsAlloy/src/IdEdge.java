import org.jgrapht.*;
import org.jgrapht.graph.*;

public class IdEdge extends DefaultEdge {
	
    private String id;

    public IdEdge(String id)  {
        this.id = id;
    }

    public String getId() {
       return id;
    }
}
