
public class Chronometer {
	private long startTm;
	private long endTm;
	
	public Chronometer () {
		startTm = 0;
		endTm = 0;
	}
	
	public void start () {
		startTm = System.nanoTime();
		endTm = System.nanoTime();
	}
	
	public void stop () {
		endTm = System.nanoTime();
	}

	public long getDelayMilliseconds() {
		return ((endTm-startTm)/1000000);
	}
	
	public double getDelaySeconds() {
		double sec = (double) ((endTm-startTm)/1000000000.0);
		//Returns with max 5 decimals
		return Math.round(sec * 100000d) / 100000d;
	}
}
