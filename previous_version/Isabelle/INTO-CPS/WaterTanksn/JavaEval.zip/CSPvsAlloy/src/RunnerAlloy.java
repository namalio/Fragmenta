
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import edu.mit.csail.sdg.alloy4compiler.parser.CompUtil;
import edu.mit.csail.sdg.alloy4.A4Reporter;
import edu.mit.csail.sdg.alloy4.Err;
import edu.mit.csail.sdg.alloy4.ErrorWarning;
import edu.mit.csail.sdg.alloy4compiler.ast.Module;
import edu.mit.csail.sdg.alloy4compiler.ast.Command;
import edu.mit.csail.sdg.alloy4compiler.translator.A4Options;
import edu.mit.csail.sdg.alloy4compiler.translator.A4Solution;
import edu.mit.csail.sdg.alloy4compiler.translator.TranslateAlloyToKodkod;

public class RunnerAlloy {
	public static final int NO_FILES = 166;
	public static String generated_folder = "/Users/wv8599/Work/Fragmenta/Isabelle/INTO-CPS/WaterTanksn/Generated/";
	
	// Alloy4 sends diagnostic messages and progress reports to the A4Reporter.
    // By default, the A4Reporter ignores all these events (but you can extend the A4Reporter to display the event for the user)
    static A4Reporter rep = new A4Reporter() {
        // For example, here we choose to display each "warning" by printing it to System.out
        @Override public void warning(ErrorWarning msg) {
            System.out.print("Relevance Warning:\n"+(msg.toString().trim())+"\n\n");
            System.out.flush();
        }
    };

    public static boolean execAlloyCheck (String fileName) throws Err {
    	boolean cycleFound = false;
    	// Loads the file name
    	Module world = 
    		CompUtil.parseEverything_fromFile(rep, null, fileName);
    
    	// Choose some default options for how you want to execute the commands
    	A4Options options = new A4Options();

    	options.solver = A4Options.SatSolver.MiniSatJNI;
    	for (Command command: world.getAllCommands()) {
    		A4Solution ans = 
    			TranslateAlloyToKodkod.execute_command(rep, world.getAllReachableSigs(), command, options);
            // Print the outcome
    		//System.out.println("Model: " + world.getModelName());
            //System.out.println(ans);
            if (ans.satisfiable()) {
            	cycleFound = false;
            }
            else 
            	cycleFound = true;
    	}   	
    	
    	// Returns whether assertion passed or not
    	return cycleFound;
    }
    
    public static void execAlloy (int i, List<ExecutionEntry> entries) throws Err {
    	String base_Str = generated_folder + "WTsn_";
    	Chronometer c = new Chronometer();
    	if (i>= 1 && i<= NO_FILES) {
    		// starts the chronometer
    		c.start();
    		boolean cycleFound = execAlloyCheck  (base_Str+i+".als");
    		// stops the chronometer
    		c.stop();
        	System.out.println("Alloy, WTsn_" + i+ ": " + msgCycleFoundOrNotFound(cycleFound) + ", " + c.getDelaySeconds() +" seconds");
        	entries.add(new ExecutionEntry(ExecEnvironment.Alloy, cycleFound, false, i, c.getDelaySeconds()));
        	// starts the chronometer
    		c.start();
    		cycleFound = execAlloyCheck  (base_Str+i+"_loop.als");
        	// stops the chronometer
    		c.stop();
        	System.out.println("Alloy, WTsn_" + i+ "_loop:" + msgCycleFoundOrNotFound(cycleFound) + ", " + c.getDelaySeconds() +" seconds");
        	entries.add(new ExecutionEntry(ExecEnvironment.Alloy, cycleFound, true, i, c.getDelaySeconds()));
    	}
    }
    
    public static String msgCycleFoundOrNotFound (boolean flag) {
    	return (flag ? "cycle Found" : "no cycle");
    }
    
	public static void main(String[] args) {
		//Creates the array for the execution entries
		List<ExecutionEntry> entries = new ArrayList<ExecutionEntry> ();
		String fileName = generated_folder + "simulation-alloy.csv";
		
        try {
        	for(int i = 1; i<= NO_FILES; i++) {
        		execAlloy (i, entries);  
        	}
        	
        	 // Writes the contents of the simulation into a csv text file
            Utils.wrLogFile (entries, fileName);
        } 
        catch (UnsupportedEncodingException error) {
            System.out.println(error);
        }
        catch (FileNotFoundException error) {
        	System.out.println(error);
        }
        catch (Exception e) {
			e.printStackTrace();
		}
	}

}
