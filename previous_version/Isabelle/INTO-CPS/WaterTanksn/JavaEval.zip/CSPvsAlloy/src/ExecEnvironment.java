
public enum ExecEnvironment {
	CSP, Alloy, Johnson
}
