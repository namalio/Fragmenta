/**
 * 
 */

/**
 * @author wv8599
 *
 */
public class ExecutionEntry {
	private ExecEnvironment env;
	private boolean cycleFound;
	private boolean loop;
	private int i;
	//The time in seconds
	private double tm;
	
	public ExecutionEntry (ExecEnvironment env, boolean cycleFound, boolean loop, int i, double tm) {
		this.env = env;
		this.cycleFound = cycleFound;
		this.loop = loop;
		this.i = i;
		this.tm = tm;
	}
	
	public int get_i () {
		return i;
	}
	
	public int getOrder () {
		int ret = 0;
		
		if (!loop)
			ret = 6 + (i*2);
		else
			ret = 7 + (i*2);
		
		return ret;
	}
	
	public double getTm () {
		return tm;
	}
	
	public String getResult () {
		String str;
		
		if (cycleFound)
			str = "cycle found";
		else
			str = "no cycle";
			
		return str;
	}
	
	public ExecEnvironment getEnv () {
		return this.env;
	}
	
	public String getKind () {
		String str;
		
		if (loop)
			str = "loop";
		else
			str = "no loop";
		
		return str;
	}
}
