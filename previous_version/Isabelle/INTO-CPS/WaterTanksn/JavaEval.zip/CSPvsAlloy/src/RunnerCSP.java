
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.jgrapht.DirectedGraph;
import org.jgrapht.alg.cycle.JohnsonSimpleCycles;
import org.xml.sax.SAXException;

import edu.mit.csail.sdg.alloy4compiler.parser.CompUtil;
import edu.mit.csail.sdg.alloy4.A4Reporter;
import edu.mit.csail.sdg.alloy4.Err;
import edu.mit.csail.sdg.alloy4.ErrorWarning;
import edu.mit.csail.sdg.alloy4compiler.ast.Module;
import edu.mit.csail.sdg.alloy4compiler.ast.Command;
import edu.mit.csail.sdg.alloy4compiler.translator.A4Options;
import edu.mit.csail.sdg.alloy4compiler.translator.A4Solution;
import edu.mit.csail.sdg.alloy4compiler.translator.TranslateAlloyToKodkod;
import uk.ac.ox.cs.fdr.*;

public class RunnerCSP {
	public static final int NO_FILES = 200;
    
    public static boolean execCSPCheck (String fileName) throws InputFileError, FileLoadError {
    	
    	Session session = new Session();
    	boolean cycleFound = true;
        session.loadFile(fileName);
        for (Assertion assertion : session.assertions()) {
        	assertion.execute(null);
        	cycleFound = !assertion.passed();
        }
        session.delete();
        
        return cycleFound;
    }
    
    public static boolean execJohnsonCheck (String fileName) throws ParserConfigurationException, 
    	IOException, SAXException {
    	
    	DirectedGraph<String, IdEdge> dg = GraphImporter.importFile(fileName);
    	
		JohnsonSimpleCycles<String, IdEdge> cycle_detector = new JohnsonSimpleCycles<String, IdEdge>(dg);
	
		List<List<String>> ls = cycle_detector.findSimpleCycles();
		
		boolean cycleFound = true;
		if (ls.isEmpty())
			cycleFound = false;
    	
        return cycleFound;
    }
    
    public static void execCSP (int i, List<ExecutionEntry> entries) 
    throws InputFileError, FileLoadError {
    	String base_Str = "/Users/wv8599/Work/Fragmenta/Isabelle/INTO-CPS/WaterTanksn/Generated/WTsn_";
    	Chronometer c = new Chronometer();
    	if (i>= 1 && i<= NO_FILES) {
    		// starts the chronometer
    		c.start();
    		boolean cycleFound = execCSPCheck  (base_Str+i+".csp");
    		// stops the chronometer
    		c.stop();
        	System.out.println("CSPT, WTsn_" + i+ ": " + msgCycleFoundOrNotFound(cycleFound) + ", " + c.getDelaySeconds() +" seconds");
        	entries.add(new ExecutionEntry(ExecEnvironment.CSP, cycleFound, false, i, c.getDelaySeconds()));
        	// starts the chronometer
    		c.start();
    		cycleFound = execCSPCheck   (base_Str+i+"_loop.csp");
        	// stops the chronometer
    		c.stop();
        	System.out.println("CSPT, WTsn_" + i+ "_loop:" + msgCycleFoundOrNotFound(cycleFound) + ", " + c.getDelaySeconds() +" seconds");
        	entries.add(new ExecutionEntry(ExecEnvironment.CSP, cycleFound, true, i, c.getDelaySeconds()));
    	}
    }
    
    public static String msgCycleFoundOrNotFound (boolean flag) {
    	return (flag ? "cycle Found" : "no cycle");
    }
    
    public static void wrLogFile (List<ExecutionEntry> entries) 
    		throws UnsupportedEncodingException,  FileNotFoundException {
    	String fileName = "/Users/wv8599/Work/Fragmenta/Isabelle/INTO-CPS/WaterTanksn/Generated/simulation-johnson.csv";
    	
    	// Creates the 'PrintWriter' object
    	PrintWriter writer = new PrintWriter(fileName, "UTF-8");
    	
    	// Writes the first row
    	writer.println("N,Size,Environment,Kind,Result,Time");
    	for (ExecutionEntry ee : entries) {
    		writer.println(ee.get_i() + ","+ ee.getOrder () +","+ee.getEnv().name() 
    			+ "," + ee.getKind() + "," + ee.getResult() + "," + ee.getTm());
    	}
    	writer.close();
    }
    
	public static void main(String[] args) {
		//Creates the array for the execution entries
		List<ExecutionEntry> entries = new ArrayList<ExecutionEntry> ();
		String fileName = "/Users/wv8599/Work/Fragmenta/Isabelle/INTO-CPS/WaterTanksn/Generated/simulation-csp.csv";
		
        try {
        	for(int i = 1; i<= NO_FILES; i++) {
        		//execAlloy (i, entries);  
        		execCSP (i, entries);
        		//execJohnson (i, entries);
        	}
        	
        	// Writes the contents of the simulation into a csv text file
            Utils.wrLogFile (entries, fileName);
        } 
        /*catch (Err e) {
        	System.out.println(e.msg);
        }*/
        catch (InputFileError error) {
            System.out.println(error);
        }
        catch (FileLoadError error) {
            System.out.println(error);
        }
        catch (UnsupportedEncodingException error) {
            System.out.println(error);
        }
        catch (FileNotFoundException error) {
        	System.out.println(error);
        }
        catch (Exception e) {
			e.printStackTrace();
		}
        
        fdr.libraryExit();
        
	}

}
