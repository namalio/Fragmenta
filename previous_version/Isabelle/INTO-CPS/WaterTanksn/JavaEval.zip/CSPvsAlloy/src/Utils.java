import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;


public class Utils {

	 public static void wrLogFile (List<ExecutionEntry> entries, String fileName) 
			 throws UnsupportedEncodingException,  FileNotFoundException {
	    	
		 // Creates the 'PrintWriter' object
	    PrintWriter writer = new PrintWriter(fileName, "UTF-8");
	    	
	    // Writes the first row
	    writer.println("N,Size,Environment,Kind,Result,Time");
	    for (ExecutionEntry ee : entries) {
	    	writer.println(ee.get_i() + ","+ ee.getOrder () +","+ee.getEnv().name() 
	    			+ "," + ee.getKind() + "," + ee.getResult() + "," + ee.getTm());
	    }
	    writer.close();
	 }
	
}
