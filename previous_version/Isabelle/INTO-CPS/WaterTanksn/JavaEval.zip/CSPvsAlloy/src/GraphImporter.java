import org.jgrapht.*;
import org.jgrapht.graph.*;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

public class GraphImporter {
	
	public static DirectedGraph<String, IdEdge> importFile (String fileName) 
			throws ParserConfigurationException, IOException, SAXException {
		DirectedGraph<String, IdEdge> dg = new DefaultDirectedGraph<String, IdEdge>(IdEdge.class);
		
	         File inputFile = new File(fileName);
	         DocumentBuilderFactory dbFactory 
	            = DocumentBuilderFactory.newInstance();
	         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	         Document doc = dBuilder.parse(inputFile);
	         doc.getDocumentElement().normalize();
	         
	         NodeList nList = doc.getElementsByTagName("node");
	         for (int i = 0; i < nList.getLength(); i++) {
	        	 Node nNode = nList.item(i);
	        	 Element eElement = (Element) nNode;
	        	 /*System.out.println(nNode.getNodeName() + " " + eElement.getAttribute("id"));*/
	        	 dg.addVertex(eElement.getAttribute("id"));
	         }
	         
	         NodeList eList = doc.getElementsByTagName("edge");
	         for (int i = 0; i < eList.getLength(); i++) {
	            Node nNode = eList.item(i);
	        	Element eElement = (Element) nNode;
	        	/*System.out.println(nNode.getNodeName() + " " 
	        	  + eElement.getAttribute("id") + ", source: " 
	        	  + eElement.getAttribute("source")
	        	  + ", target: " + eElement.getAttribute("target"));*/
	        	
	        	dg.addEdge(eElement.getAttribute("source"), 
	        	   eElement.getAttribute("target"), new IdEdge(eElement.getAttribute("id")));
	         }
		
		return dg;
	}
	
}
