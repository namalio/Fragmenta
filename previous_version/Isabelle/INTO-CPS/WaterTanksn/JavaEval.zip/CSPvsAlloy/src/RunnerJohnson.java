
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.jgrapht.DirectedGraph;
import org.jgrapht.alg.cycle.JohnsonSimpleCycles;
import org.xml.sax.SAXException;

import edu.mit.csail.sdg.alloy4compiler.parser.CompUtil;
import edu.mit.csail.sdg.alloy4.A4Reporter;
import edu.mit.csail.sdg.alloy4.Err;
import edu.mit.csail.sdg.alloy4.ErrorWarning;
import edu.mit.csail.sdg.alloy4compiler.ast.Module;
import edu.mit.csail.sdg.alloy4compiler.ast.Command;
import edu.mit.csail.sdg.alloy4compiler.translator.A4Options;
import edu.mit.csail.sdg.alloy4compiler.translator.A4Solution;
import edu.mit.csail.sdg.alloy4compiler.translator.TranslateAlloyToKodkod;
import uk.ac.ox.cs.fdr.*;

public class RunnerJohnson {
	public static final int NO_FILES = 200;
	public static String generated_folder = "/Users/wv8599/Work/Fragmenta/Isabelle/INTO-CPS/WaterTanksn/Generated/";
    
    public static boolean execJohnsonCheck (String fileName) throws ParserConfigurationException, 
    	IOException, SAXException {
    	
    	DirectedGraph<String, IdEdge> dg = GraphImporter.importFile(fileName);
    	
		JohnsonSimpleCycles<String, IdEdge> cycle_detector = new JohnsonSimpleCycles<String, IdEdge>(dg);
	
		List<List<String>> ls = cycle_detector.findSimpleCycles();
		
		boolean cycleFound = true;
		if (ls.isEmpty())
			cycleFound = false;
    	
        return cycleFound;
    }
    
    public static void execJohnson (int i, List<ExecutionEntry> entries) 
    throws ParserConfigurationException, IOException, SAXException {
    	String base_Str = generated_folder + "WTsn_";
    	Chronometer c = new Chronometer();
    	if (i>= 1 && i<= NO_FILES) {
    		// starts the chronometer
    		c.start();
    		boolean cycleFound = execJohnsonCheck (base_Str+i+".xml");
    		// stops the chronometer
    		c.stop();
        	System.out.println("Johnson algorithm, WTsn_" + i+ ": " + msgCycleFoundOrNotFound(cycleFound) + ", " + c.getDelaySeconds() +" seconds");
        	entries.add(new ExecutionEntry(ExecEnvironment.Johnson, cycleFound, false, i, c.getDelaySeconds()));
        	// starts the chronometer
    		c.start();
    		cycleFound = execJohnsonCheck (base_Str+i+"_loop.xml");
        	// stops the chronometer
    		c.stop();
        	System.out.println("Johnson algorithm, WTsn_" + i+ "_loop:" + msgCycleFoundOrNotFound(cycleFound) + ", " + c.getDelaySeconds() +" seconds");
        	entries.add(new ExecutionEntry(ExecEnvironment.Johnson, cycleFound, true, i, c.getDelaySeconds()));
    	}
    }
    
    public static String msgCycleFoundOrNotFound (boolean flag) {
    	return (flag ? "cycle Found" : "no cycle");
    }
    
	public static void main(String[] args) {
		//Creates the array for the execution entries
		List<ExecutionEntry> entries = new ArrayList<ExecutionEntry> ();
		String fileName = generated_folder + "simulation-johnson.csv";
		
        try {
        	for(int i = 1; i<= NO_FILES; i++) {
        		execJohnson (i, entries);
        	}
        	
        	 // Writes the contents of the simulation into a csv text file
            Utils.wrLogFile (entries, fileName);
        } 
        catch (InputFileError error) {
            System.out.println(error);
        }
        catch (FileLoadError error) {
            System.out.println(error);
        }
        catch (UnsupportedEncodingException error) {
            System.out.println(error);
        }
        catch (FileNotFoundException error) {
        	System.out.println(error);
        }
        catch (Exception e) {
			e.printStackTrace();
		}
	}

}
